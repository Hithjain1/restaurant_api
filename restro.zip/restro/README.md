# Restaurant Food App (Node.js + Express + MongoDB)

A simple REST API for managing users, authentication, and food-related data, built with Node.js, Express, MongoDB, and Mongoose.

## Features

- User registration and login with JWT authentication
- Protected routes
- MongoDB for data storage
- Environment configuration via dotenv
- REST API tested with Postman
- Local development with MongoDB Compass

---

## Getting Started

### Prerequisites

- Node.js ≥ v14
- MongoDB (Atlas or local)
- MongoDB Compass (GUI for managing the database)
- Postman (API testing)

---

### Installation

1. Clone this repository:
```bash
git clone https://github.com/your-username/nodejs-resturant-food-app.git
```

2. Install dependencies:
```bash
npm install
```

3. Create a .env file in the root directory:
```env
PORT=5000
MONGO_URI=your_mongodb_connection_string
JWT_SECRET=your_jwt_secret
```

4. Run the server:
```bash
npm start
```

Or with nodemon (for development):
```bash
npx nodemon server.js
```

---

## 📦 API Usage with Postman

1. Start the server.
2. Open Postman.
3. Import or create the following requests:

| Method | Endpoint                  | Description         |
|--------|---------------------------|---------------------|
| POST   | /api/v1/auth/register     | Register new user   |
| POST   | /api/v1/auth/login        | Login user          |
| GET    | /api/v1/user/getUser      | Get logged-in user  |

4. For protected routes, add this header:

```http
Authorization: Bearer <your_token>
```

You get the token from the login route.

---

## MongoDB Setup (with Compass)

1. If using MongoDB Compass (local):
   - Open Compass and connect to:
     ```
     mongodb://localhost:27017
     ```
   - Create a database (e.g., foodapp) and collections like users or items.

2. If using MongoDB Atlas:
   - Get your connection URI from the Atlas dashboard.
   - Replace <username>, <password>, and <dbname> with your credentials.
   - Example:
     ```
     mongodb+srv://john:password123@cluster0.mongodb.net/foodapp?retryWrites=true&w=majority
     ```

---

## Testing Notes

- Use Postman to test the registration, login, and protected endpoints.
- MongoDB Compass allows you to visually inspect inserted users, food items, etc.

---

##  Project Structure

nodejs-resturant-food-app-main/
│
├── controllers/        # Route logic
├── middlewares/        # Auth middleware
├── models/             # Mongoose schemas
├── routes/             # Express route handlers
├── config/             # DB config
├── .env                # Environment variables
├── server.js           # Entry point
